package com.luv2code.ecommerce.dto;

import lombok.Data;
import lombok.NonNull;

@Data
public class PurchaseResponse {
    private final String orderTrakingNumber;

//    @NonNull
//    private String orderTrakingNumber;
}
